<?php

namespace includes;

use includes\helpers\simple_html_dom;

class App {

    public static function get_html($source) {
        require_once __DIR__ . '/helpers/simple_html_dom.php';
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_COOKIE, "");
        curl_setopt($curl, CURLOPT_URL, $source);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, "");
        curl_setopt($curl, CURLOPT_REFERER, $source);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $str = curl_exec($curl);
        curl_close($curl);

        $html = new simple_html_dom();
        $html->load($str);
        return $html;
    }

    public static function prepare($array) {
        $cleanArr = [];

        foreach ($array as $item) {
            $cleanArr[] = trim(htmlspecialchars(strip_tags($item)));
        }

        return $cleanArr;
    }

}