<?php

namespace includes;

class Database {

    private $db;

    public function __construct()
    {
        $config = (require _BASEDIR_ . '/config.php')['db'];
        $this->db = new \PDO('mysql:host=' . $config['host'] . ';dbname=' . $config['dbname'], $config['user'], $config['password']);
    }

    public function query($sql, $params)
    {
        $db = $this->db;
        $sth = $db->prepare($sql);
        $sth->execute($params);

        if (!$sth) {
            echo $sth->errorInfo();
            die;
        }
    }

}