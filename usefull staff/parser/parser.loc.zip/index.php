<?php

define('_BASEDIR_', __DIR__);

spl_autoload_register(function ($className) {
    require_once __DIR__ . '/' . $className . '.php';
});

use includes\App;
use includes\Database;


/*--------*/
$html = App::get_html('');


foreach($html->find('') as $element) {
   $html_city = App::get_html($element);

   $db = new Database();
   $query = "INSERT INTO `` () VALUES ()";
   $params = App::prepare([]);
   $db->query($query, $params);
}

echo 'Успех';