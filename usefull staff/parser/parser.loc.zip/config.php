<?php

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'parser_db',
        'user' => 'root',
        'password' => '',
    ]
];