<?php
namespace morphos;

interface Gender
{
    const MALE = 'm';
    const FEMALE = 'f';
    const NEUTER = 'n';
}
