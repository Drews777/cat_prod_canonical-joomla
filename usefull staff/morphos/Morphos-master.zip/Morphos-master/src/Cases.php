<?php
namespace morphos;

interface Cases
{
    const NOMINATIVE = 'nominative';
    const GENITIVE = 'genitive';
    const GENETIVE = 'genitive';
    const DATIVE = 'dative';
    const ACCUSATIVE = 'accusative';
    const ABLATIVE = 'ablative';
    const PREPOSITIONAL = 'prepositional';
}
